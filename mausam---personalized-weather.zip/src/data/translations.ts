import { LanguageCode, PersonaId } from '../types';

export interface TranslationDictionary {
  appTitle: string;
  appSubtitle: string;
  officialSubtitle: string;
  primaryBadge: string;
  liveBadge: string;
  estimatedBadge: string;
  refreshTooltip: string;
  customizePersonas: string;
  viewMap: string;
  savedPlaces: string;
  offlineBanner: string;
  becauseYouFollow: string;
  tapToDeepDive: string;
  chooseLanguage: string;
  selectPersonasPrompt: string;
  selectUpToThree: string;
  primarySelectionNote: string;
  continueBtn: string;
  saveChanges: string;
  searchCityPlaceholder: string;
  currentLocation: string;
  close: string;
  personas: Record<PersonaId, {
    name: string;
    tagline: string;
    cardTitle?: string;
    description: string;
  }>;
}

export const TRANSLATIONS: Record<LanguageCode, TranslationDictionary> = {
  en: {
    appTitle: 'Mausam',
    appSubtitle: 'Personalized Weather Insights',
    officialSubtitle: 'India Meteorological Department (IMD) • Ministry of Earth Sciences',
    primaryBadge: 'PRIMARY',
    liveBadge: 'LIVE',
    estimatedBadge: 'ESTIMATED',
    refreshTooltip: 'Refresh feed',
    customizePersonas: 'Customize Personas',
    viewMap: 'Interactive Map',
    savedPlaces: 'Saved Places',
    offlineBanner: 'Offline Mode: Showing cached IMD observations and numerical forecast.',
    becauseYouFollow: 'Because you follow',
    tapToDeepDive: 'Tap for deep-dive metrics & tools',
    chooseLanguage: 'Select Language / भाषा चुनें',
    selectPersonasPrompt: 'What should Mausam watch for you?',
    selectUpToThree: 'Select 1 to 3 personas matching your lifestyle.',
    primarySelectionNote: 'Your first selected persona is pinned as your Primary priority.',
    continueBtn: 'Continue to Personalized Feed',
    saveChanges: 'Save Preferences',
    searchCityPlaceholder: 'Search city, beach, hill station...',
    currentLocation: 'Current Location',
    close: 'Close',
    personas: {
      health: {
        name: 'Health & Allergy',
        tagline: 'AQI, Pollen & Skin Protection',
        cardTitle: 'Air Quality & Pollen Safety Report',
        description: 'Track Air Quality Index, pollen allergens, UV burn times and respiratory humidity.'
      },
      fitness: {
        name: 'Fitness & Running',
        tagline: 'Best Running Hours & Heat Alerts',
        cardTitle: 'Optimal Exercise Time & Heat Index',
        description: 'Optimize training with ideal exercise hours, astronomical sunrise/sunset, and wind speed.'
      },
      beach: {
        name: 'Beach & Coastal',
        tagline: 'Tides, Swells & Sea Safety',
        cardTitle: 'Tides, Swells & Coastal Safety',
        description: 'Check tide heights, wave swell, sea surface temp and safety flag classifications.'
      },
      traveller: {
        name: 'Travel & Trips',
        tagline: 'Multi-City & Flight Packing',
        cardTitle: 'Flight Weather & Packing Advisory',
        description: 'Saved destinations, aviation storm advisories, and context-aware packing suggestions.'
      },
      parent: {
        name: 'Parents & Family',
        tagline: 'School Commute & Rain Radar',
        cardTitle: 'School Commute & Rain Radar',
        description: 'Pinpoint 7-9 AM & 2-4 PM school run conditions, downpour radar, and outdoor safety.'
      },
      commuter: {
        name: 'Daily Commute',
        tagline: 'Visibility & Traffic Impacts',
        cardTitle: 'Road Visibility & Delay Estimate',
        description: 'Fog density, expressway waterlogging alerts, storm delays, and departure timing.'
      },
      agriculture: {
        name: 'Agriculture & Gardeners',
        tagline: 'Soil Moisture & Frost Alerts',
        cardTitle: 'Soil Moisture & Agromet Guidance',
        description: 'Subsurface soil water, 7-day rainfall totals, frost risk, and Kharif/Rabi ICAR advisories.'
      },
      events: {
        name: 'Outdoor Events',
        tagline: '14-Day Outlook & Comfort Index',
        cardTitle: 'Outdoor Event & Comfort Index',
        description: 'Extended precipitation probabilities, gathering comfort index, and backup date recommendations.'
      }
    }
  },
  hi: {
    appTitle: 'मौसम',
    appSubtitle: 'व्यक्तिगत मौसम पूर्वानुमान',
    officialSubtitle: 'भारत मौसम विज्ञान विभाग (IMD) • पृथ्वी विज्ञान मंत्रालय',
    primaryBadge: 'मुख्य (Primary)',
    liveBadge: 'सटीक अवलोकन (LIVE)',
    estimatedBadge: 'अनुमानित',
    refreshTooltip: 'अपडेट करें',
    customizePersonas: 'प्रोफ़ाइल बदलें',
    viewMap: 'मौसम मानचित्र',
    savedPlaces: 'सहेजे गए स्थान',
    offlineBanner: 'ऑफ़लाइन मोड: पहले से संग्रहित मौसम डेटा प्रदर्शित किया जा रहा है।',
    becauseYouFollow: 'क्योंकि आप अनुसरण करते हैं',
    tapToDeepDive: 'विस्तृत विवरण देखें',
    chooseLanguage: 'अपनी भाषा चुनें',
    selectPersonasPrompt: 'अपनी पसंदीदा श्रेणियां चुनें',
    selectUpToThree: '1 से 3 श्रेणियां चुनें जो आपकी जीवनशैली से मेल खाती हों। पहली चुनी गई श्रेणी मुख्य (Primary) होगी',
    primarySelectionNote: 'आपकी पहली चुनी गई श्रेणी मुख्य (Primary) होगी।',
    continueBtn: 'जारी रखें →',
    saveChanges: 'मौसम ऐप में प्रवेश करें ✓',
    searchCityPlaceholder: 'शहर खोजें...',
    currentLocation: 'वर्तमान GPS स्थान का उपयोग करें',
    close: 'बंद करें',
    personas: {
      health: {
        name: 'स्वास्थ्य और एलर्जी',
        tagline: 'वायु गुणवत्ता (AQI), पराग कण, UV इंडेक्स',
        cardTitle: 'वायु गुणवत्ता एवं परागकण सुरक्षा रिपोर्ट',
        description: 'वायु गुणवत्ता (AQI), पराग कण, UV इंडेक्स एवं त्वचा/श्वसन संबंधी सलाह।'
      },
      fitness: {
        name: 'फिटनेस और दौड़',
        tagline: 'व्यायाम के लिए उत्तम समय व हीट अलर्ट',
        cardTitle: 'व्यायाम हेतु अनुकूल समय व ताप सूचकांक',
        description: 'व्यायाम के लिए उत्तम सुबह/शाम के घंटे, तापमान, हवा की गति और हीट-स्ट्रोक अलर्ट।'
      },
      beach: {
        name: 'तटीय व समुद्र',
        tagline: 'ज्वार-भाटा, लहरें व पानी का तापमान',
        cardTitle: 'ज्वार-भाटा, समुद्री लहरें व तटीय सुरक्षा',
        description: 'ज्वार-भाटा का समय, समुद्री लहरें, पानी का तापमान और तैराकी सुरक्षा अलर्ट।'
      },
      traveller: {
        name: 'यात्री व भ्रमण',
        tagline: 'विभिन्न शहरों का मौसम व पैकिंग सलाह',
        cardTitle: 'उड़ान मौसम, गंतव्य रिपोर्ट व पैकिंग सलाह',
        description: 'विभिन्न शहरों का मौसम, वेदर अलर्ट और उड़ान में रेनकोट/कपड़ों के सुझाव।'
      },
      parent: {
        name: 'अभिभावक व परिवार',
        tagline: 'स्कूल आने-जाने का समय (7-9 व 2-4)',
        cardTitle: 'स्कूल आवागमन व वर्षा राडार रिपोर्ट',
        description: 'स्कूल आने-जाने का मौसम (सुबह 7-9 व दोपहर 2-4), वर्षा का अलर्ट और बाल सुरक्षा।'
      },
      commuter: {
        name: 'दैनिक आवागमन',
        tagline: 'सड़क पर दृश्यता (कोहरा/धुंध) व देरी',
        cardTitle: 'सड़क दृश्यता व यात्रा में देरी का अनुमान',
        description: 'सड़क पर दृश्यता (कोहरा/धुंध), जलभराव की संभावना और यात्रा में लगने वाला समय।'
      },
      agriculture: {
        name: 'कृषि एवं बागवानी',
        tagline: 'मिट्टी की नमी, 7 दिवसीय वर्षा व पाला',
        cardTitle: 'मृदा नमी, वर्षा पूर्वानुमान व कृषि सलाह',
        description: 'मिट्टी की नमी, 7 दिवसीय वर्षा संभावना, पाला चेतावनी और मौसम आधारित फसल सलाह।'
      },
      events: {
        name: 'खुले मैदान में आयोजन',
        tagline: '14 दिवसीय वर्षा का पूर्वानुमान व उमस',
        cardTitle: 'खुले मैदान में आयोजन व कम्फर्ट इंडेक्स',
        description: '14 दिवसीय वर्षा का पूर्वानुमान, उमस सूचकांक एवं विवाह/इवेंट उपयुक्तता।'
      }
    }
  },
  mr: {
    appTitle: 'हवामान',
    appSubtitle: 'वैयक्तिकृत हवामान अंदाज',
    officialSubtitle: 'भारतीय हवामान विभाग (IMD) • पृथ्वी विज्ञान मंत्रालय',
    primaryBadge: 'प्राथमिक',
    liveBadge: 'थेट (LIVE)',
    estimatedBadge: 'अंदाजित',
    refreshTooltip: 'रिफ्रेश करा',
    customizePersonas: 'व्यक्तिमत्त्व निवडा',
    viewMap: 'नकाशा पहा',
    savedPlaces: 'जतन केलेली ठिकाणे',
    offlineBanner: 'ऑफलाइन मोड: जतन केलेला डेटा दाखवत आहे.',
    becauseYouFollow: 'कारण तुम्ही निवडले आहे',
    tapToDeepDive: 'सविस्तर माहिती आणि आलेखांसाठी टॅप करा',
    chooseLanguage: 'भाषा निवडा',
    selectPersonasPrompt: 'तुमच्यासाठी हवामानाने कशावर लक्ष ठेवावे?',
    selectUpToThree: '१ ते ३ पर्याय निवडा. पहिला पर्याय मुख्य असेल.',
    primarySelectionNote: 'तुमची पहिली निवड अग्रक्रमाने सर्वात वर दिसेल.',
    continueBtn: 'पुढे जा',
    saveChanges: 'बदल जतन करा',
    searchCityPlaceholder: 'शहर किंवा समुद्रकिनारा शोधा...',
    currentLocation: 'सध्याचे स्थान',
    close: 'बंद करा',
    personas: {
      health: {
        name: 'आरोग्य जागरूक',
        tagline: 'हवेची गुणवत्ता आणि ॲलर्जी',
        description: 'AQI, परागकण, अतिनील किरणे आणि दम्यासाठी आवश्यक सूचना.'
      },
      fitness: {
        name: 'कसरत व धावणे',
        tagline: 'धावण्यासाठी उत्तम वेळ व वारा',
        description: 'सूर्योदय, वाऱ्याचा वेग आणि व्यायाम करण्यासाठी सर्वोत्तम वेळ.'
      },
      beach: {
        name: 'किनारा व सर्फिंग',
        tagline: 'भरती-ओहोटी व लाटा',
        description: 'भरतीची वेळ, समुद्राचे तापमान आणि सुरक्षितता निर्देशांक.'
      },
      traveller: {
        name: 'प्रवासी व पर्यटन',
        tagline: 'उड्डाणे व पॅकिंग सूचना',
        description: 'इतर शहरांचा हवामान अंदाज आणि प्रवासासाठी रेनकोट/कपड्यांचे सल्ले.'
      },
      parent: {
        name: 'पालक व कुटुंब',
        tagline: 'शाळेची वेळ व पावसाचा अंदाज',
        description: 'सकाळी ६-९ व दुपारी २-४ दरम्यानची स्थिती आणि पावसाची शक्यता.'
      },
      agriculture: {
        name: 'शेती व बागकाम',
        tagline: 'जमिनीतील ओलावा व पर्जन्यमान',
        description: 'मातीतील ओलावा, ७ दिवसांचा पाऊस, गारपीट/थंडीचा इशारा आणि पीक सल्ला.'
      },
      commuter: {
        name: 'प्रवासी (कम्युटर)',
        tagline: 'धुके व वाहतूक कोंडी',
        description: 'रस्त्यावरील दृश्यमानता, पाणी साचणे आणि प्रवासाचे नियोजन.'
      },
      events: {
        name: 'समारंभ नियोजक',
        tagline: '१४ दिवसांचा अंदाज व कम्फर्ट इंडेक्स',
        description: 'लग्नकार्य व मैदानी कार्यक्रमांसाठी पावसाची शक्यता व पर्यायी तारखा.'
      }
    }
  },
  ta: {
    appTitle: 'வானிலை',
    appSubtitle: 'தனிப்பயனாக்கப்பட்ட வானிலை தகவல்',
    officialSubtitle: 'இந்திய வானிலை ஆய்வு மையம் (IMD)',
    primaryBadge: 'முதன்மை',
    liveBadge: 'நேரலை',
    estimatedBadge: 'மதிப்பிடப்பட்டது',
    refreshTooltip: 'புதுப்பிக்கவும்',
    customizePersonas: 'விருப்பங்களை மாற்றுக',
    viewMap: 'வரைபடம்',
    savedPlaces: 'சேமிக்கப்பட்ட இடங்கள்',
    offlineBanner: 'ஆஃப்லைன் பயன்முறை: முந்தைய தகவல் காட்டப்படுகிறது.',
    becauseYouFollow: 'நீங்கள் பின்பற்றுவதால்',
    tapToDeepDive: 'முழு விவரங்களை அறிய தட்டவும்',
    chooseLanguage: 'மொழியைத் தேர்ந்தெடுக்கவும்',
    selectPersonasPrompt: 'உங்களுக்கு என்ன தகவல் வேண்டும்?',
    selectUpToThree: '1 முதல் 3 விருப்பங்களைத் தேர்ந்தெடுக்கவும்.',
    primarySelectionNote: 'உங்கள் முதல் தேர்வு முதன்மை இடத்தைப் பெறும்.',
    continueBtn: 'தொடரவும்',
    saveChanges: 'சேமிக்க',
    searchCityPlaceholder: 'நகரம் அல்லது கடற்கரை தேடுங்கள்...',
    currentLocation: 'தற்போதைய இடம்',
    close: 'மூடு',
    personas: {
      health: {
        name: 'சுகாதார விழிப்புணர்வு',
        tagline: 'காற்று தரம் (AQI) மற்றும் மகரந்தம்',
        description: 'காற்று தரம், ஒவ்வாமை மற்றும் புற ஊதாக்கதிர் தாக்கங்களை கண்காணிக்கவும்.'
      },
      fitness: {
        name: 'உடற்பயிற்சி & ஓட்டம்',
        tagline: 'சிறந்த உடற்பயிற்சி நேரம்',
        description: 'சூரிய உதயம்/மறைவு, காற்றின் வேகம் மற்றும் பாதுகாப்பான நேரம்.'
      },
      beach: {
        name: 'கடற்கரை & சர்ஃபிங்',
        tagline: 'அலைகள் மற்றும் கடல் பாதுகாப்பு',
        description: 'அலை நேரம், நீர் வெப்பநிலை மற்றும் பாதுகாப்பு குறியீடு.'
      },
      traveller: {
        name: 'பயணிகள்',
        tagline: 'விமான எச்சரிக்கை மற்றும் ஆடைகள்',
        description: 'பயண இடங்கள், வானிலை முன்னறிவிப்பு மற்றும் பேக்கிங் பரிந்துரை.'
      },
      parent: {
        name: 'பெற்றோர் & குடும்பம்',
        tagline: 'பள்ளி நேரம் மற்றும் மழை',
        description: 'காலை 6-9 & மாலை 2-4 பள்ளி நேர வானிலை மற்றும் மழை எச்சரிக்கை.'
      },
      agriculture: {
        name: 'விவசாயம் & தோட்டம்',
        tagline: 'மண் ஈரப்பதம் & மழை கணிப்பு',
        description: 'மண் ஈரப்பதம், 7 நாள் மழை மற்றும் பயிர் ஆலோசனை.'
      },
      commuter: {
        name: 'தினசரி பயணிகள்',
        tagline: 'பனிமூட்டம் & போக்குவரத்து',
        description: 'பார்வைத்திறன், சாலை வெள்ளம் மற்றும் பயண தாமத எச்சரிக்கை.'
      },
      events: {
        name: 'நிகழ்ச்சி திட்டமிடுபவர்',
        tagline: '14 நாள் கணிப்பு & திருமண ஏற்பாடு',
        description: 'மழை வாய்ப்பு மற்றும் திறந்தவெளி நிகழ்ச்சிகளுக்கான சிறந்த தேதிகள்.'
      }
    }
  },
  bn: {
    appTitle: 'মৌসম',
    appSubtitle: 'ব্যক্তিগতকৃত আবহাওয়া তথ্য',
    officialSubtitle: 'ভারত আবহাওয়া বিজ্ঞান বিভাগ (IMD)',
    primaryBadge: 'প্রধান',
    liveBadge: 'লাইভ',
    estimatedBadge: 'আনুমানিক',
    refreshTooltip: 'রিফ্রেশ করুন',
    customizePersonas: 'পছন্দ পরিবর্তন',
    viewMap: 'মানচিত্র দেখুন',
    savedPlaces: 'সংরক্ষিত স্থান',
    offlineBanner: 'অফলাইন মোড: পূর্ববর্তী সংরক্ষিত তথ্য প্রদর্শিত হচ্ছে।',
    becauseYouFollow: 'কারণ আপনি অনুসরণ করছেন',
    tapToDeepDive: 'বিস্তারিত ও গ্রাফ দেখতে ট্যাপ করুন',
    chooseLanguage: 'ভাষা নির্বাচন করুন',
    selectPersonasPrompt: 'মৌসম আপনার জন্য কী পর্যবেক্ষণ করবে?',
    selectUpToThree: '১ থেকে ৩টি পছন্দ নির্বাচন করুন। প্রথমটি প্রধান হবে।',
    primarySelectionNote: 'আপনার প্রথম নির্বাচনটি শীর্ষে পিন করা থাকবে।',
    continueBtn: 'এগিয়ে যান',
    saveChanges: 'সংরক্ষণ করুন',
    searchCityPlaceholder: 'শহর বা সৈকত খুঁজুন...',
    currentLocation: 'বর্তমান অবস্থান',
    close: 'বন্ধ করুন',
    personas: {
      health: {
        name: 'স্বাস্থ্য সচেতন',
        tagline: 'বায়ুর মান ও অ্যালার্জি তথ্য',
        description: 'AQI, পরাগরেণু, UV সূচক এবং শ্বাসকষ্টের জন্য সতর্কতা।'
      },
      fitness: {
        name: 'ফিটনেস ও দৌড়',
        tagline: 'ব্যায়ামের সেরা সময়',
        description: 'সূর্যোদয়/সূর্যাস্ত, বাতাসের গতি এবং উপযুক্ত ব্যায়ামের সময়।'
      },
      beach: {
        name: 'সৈকত ও সার্ফার',
        tagline: 'জোয়ার-ভাটা ও সমুদ্র সতর্কতা',
        description: 'জোয়ারের সময়, ঢেউয়ের উচ্চতা ও সাঁতারের জন্য পানির অবস্থা।'
      },
      traveller: {
        name: 'ভ্রমণকারী',
        tagline: 'গন্তব্য ও প্যাকিং পরামর্শ',
        description: 'উড়ান আবহাওয়া সতর্কতা এবং বৃষ্টির জন্য রেইনকোট পরামর্শ।'
      },
      parent: {
        name: 'অভিভাবক ও পরিবার',
        tagline: 'স্কুল যাত্রা ও বৃষ্টি রাডার',
        description: 'সকাল ৬-৯ ও দুপুর ২-৪ স্কুল সময়ের বৃষ্টি ও সুরক্ষা নির্দেশিকা।'
      },
      agriculture: {
        name: 'কৃষি ও বাগান',
        tagline: 'মাটির আর্দ্রতা ও ফসলের পরামর্শ',
        description: 'মাটির আর্দ্রতা, ৭ দিনের বৃষ্টি এবং খরিফ/রবি শস্যের গাইড।'
      },
      commuter: {
        name: 'নিত্যযাত্রী',
        tagline: 'দৃশ্যমানতা ও ট্রাফিক প্রভাব',
        description: 'কুয়াশা, রাস্তায় জল জমা এবং নিরাপদ যাত্রার সময়।'
      },
      events: {
        name: 'ইভেন্ট প্ল্যানার',
        tagline: '১৪ দিনের পূর্বাভাস ও স্বস্তি সূচক',
        description: 'বিবাহ বা অনুষ্ঠানের জন্য বৃষ্টির সম্ভাবনা ও বিকল্প তারিখ।'
      }
    }
  }
};

export const PERSONA_METAS: Record<PersonaId, { icon: string; color: string; accentBg: string; borderAccent: string }> = {
  health: {
    icon: '💚',
    color: '#10b981',
    accentBg: 'bg-emerald-500/10',
    borderAccent: 'border-emerald-500'
  },
  fitness: {
    icon: '🏃',
    color: '#f97316',
    accentBg: 'bg-orange-500/10',
    borderAccent: 'border-orange-500'
  },
  beach: {
    icon: '🏖️',
    color: '#06b6d4',
    accentBg: 'bg-cyan-500/10',
    borderAccent: 'border-cyan-500'
  },
  traveller: {
    icon: '✈️',
    color: '#8b5cf6',
    accentBg: 'bg-purple-500/10',
    borderAccent: 'border-purple-500'
  },
  parent: {
    icon: '👨‍👩‍👧',
    color: '#ec4899',
    accentBg: 'bg-pink-500/10',
    borderAccent: 'border-pink-500'
  },
  agriculture: {
    icon: '🌾',
    color: '#84cc16',
    accentBg: 'bg-lime-500/10',
    borderAccent: 'border-lime-500'
  },
  commuter: {
    icon: '🚗',
    color: '#64748b',
    accentBg: 'bg-slate-500/10',
    borderAccent: 'border-slate-500'
  },
  events: {
    icon: '🎉',
    color: '#eab308',
    accentBg: 'bg-amber-500/10',
    borderAccent: 'border-amber-500'
  }
};
